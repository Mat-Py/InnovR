function A=gol1(nl, nr, n)
A = [vdm(-nl:0, n); vdm(1:nr, n)];
